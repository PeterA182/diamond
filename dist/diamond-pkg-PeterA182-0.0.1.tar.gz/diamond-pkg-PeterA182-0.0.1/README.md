diamond class
	add daily games --> dmd.summary
	add boxscores --> dmd.box
	add startingPitcher
	add bullpenPitchers
	add starter_rolling
	add bullpen_rolling
	add wager_table

TODO
        fit batter cluster model
        fit starting pitcher cluster model
        fit bullpen cluster model
        Rolling batter stats outlier detection model
        
